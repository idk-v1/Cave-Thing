/*
A shitty game that is sort of like Minecraft from a top down view, but I don't want to learn 3d maths.
If you are reading this, good luck. This code follows the rule of "if it works, it works".
- Ben Hamilton - Nov 6, 2022
*/

#include "SFML/Graphics.hpp"
#include <chrono>
#include <thread>
#include <windows.h>
#include <iostream>
#include <sstream>
#include "SimplexNoise.hpp"
#include <vector>
#include <functional>
#include <string>
#include <fstream>
#include <iomanip>
#include <direct.h>


SimplexNoise noise;


struct Item
{
	int
		id = 0,
		count = 0;
	Item(int idP, int countP)
	{
		id = idP;
		count = countP;
	}
};


struct Tile
{
	char
		id = 0,
		grow = 0,
		light = 0;
};
sf::Texture* tex[256];


struct Element
{
	int
		x = 0,
		y = 0,
		w = 0,
		h = 0,
		fsize = 30;
	std::string
		str = "",
		src = "res/among.png";
	char evt = '0';

	Element(int xP, int yP, int wP, int hP, int fsizeP, char evtP, std::string strP, std::string srcP)
	{
		x = xP * 15;
		y = yP * 15;
		w = wP * 15;
		h = hP * 15;
		fsize = fsizeP;
		evt = evtP;
		str = strP;
		src = srcP;
	}
};


struct Menu
{
	std::vector<Element*> img;
	std::vector<Element*> lbl;
	std::vector<Element*> ttl;
	std::vector<Element*> inp;
	std::vector<Element*> btn;
	std::vector<Element*> tgl;
	int selID = -1;
};
std::vector<Menu*> menu;


POINT mpos;


int
	width = 960,
	height = 720,
	mwidth = 500,
	mheight = 500,

	tps = 1000 / 20,

	tilesize = 32,
	viewdist = 1,
	loaddist = 3,

	pagenum = 0;

long
	now = 0,
	last = 0,
	delta = 0,

	ticks = 0,
	ticksS = 0,

	seed;

bool
	w = false, wL = false,
	a = false, aL = false,
	s = false, sL = false,
	d = false, dL = false,
	q = false, qL = false,
	e = false, eL = false,
	r = false, rL = false,
	esc = false, escL = false,
	ctrl = false, ctrlL = false,
	shift = false, shiftL = false,
	enter = false, enterL = false,

	left = false, leftL = false,
	right = false, rightL = false,

	focus = true,
	ininv = false,
	ingame = false,
	pause = false;


struct Chunk
{
	int
		x = 0,
		y = 0;
	bool saved = false;
	Tile** tiles[16];
	Tile** tilesf[16];
	Chunk(int xP, int yP)
	{
		x = xP;
		y = yP;

		for (int x = 0; x < 16; x++)
		{
			tiles[x] = new Tile*[16];
			tilesf[x] = new Tile*[16];
			for (int y = 0; y < 16; y++)
			{
				tiles[x][y] = new Tile;
				tilesf[x][y] = new Tile;
			}
		}
	}
};
std::vector<Chunk*> chunks;


struct Player
{
	int
		x = 0,
		y = 0,
		xc = 0,
		yc = 0,
		rad = tilesize * 3,
		rot = 0,
		anprog = 0,
		mineprog = 0,
		minedist = 5,
		minedistcur = 0,
		minespeed = 1,
		invsel = 0,
		health = 50,
		damage = 10,
		speed = 2;
	bool
		light = true;
	Item* inv[5 * 11 - 1 - 1];
	Item tool = Item(0, 0);
	/*
		00000000000
		00000000000
		00000000000
		00000000000
		000000000 1
	*/
#pragma warning (disable:26495)
	Player()
	{
		for (int i = 0; i < 5 * 11 - 1 - 1; i++)
		{
			inv[i] = new Item(0, 0);
		}
	}
};
Player p;


sf::RenderWindow window(sf::VideoMode(width, height), "Cave", sf::Style::Titlebar | sf::Style::Close);
sf::RectangleShape rect;
sf::ConvexShape cnvx;
sf::Texture texture;
sf::Font font;
sf::Text text;


void save()
{

}


void load()
{

}


int getChunkID(int x, int y, int xc, int yc)
{
	int xx = xc;
	int yy = yc;
	if (x < 0) xx--;
	if (x >= 16) xx++;
	if (y < 0) yy--;
	if (y >= 16) yy++;

	for (int i = 0; i < chunks.size(); i++)
		if (chunks[i]->x == xx && chunks[i]->y == yy)
			return i;
	return -1;
}


int getTileID(int x, int y, int xc, int yc)
{
	int xx = x;
	int yy = y;
	int i = getChunkID(x, y, xc, yc);
	if (i != -1)
	{
		if (x < 0) xx += 16;
		if (x >= 16) xx -= 16;
		if (y < 0) yy += 16;
		if (y >= 16) yy -= 16;
		return chunks[i]->tiles[xx][yy]->id;
	}
	return -1;
}


void setTileID(int x, int y, int xc, int yc, int id)
{
	int xx = x;
	int yy = y;
	int i = getChunkID(x, y, xc, yc);
	if (i != -1)
	{
		if (x < 0) xx += 16;
		if (x >= 16) xx -= 16;
		if (y < 0) yy += 16;
		if (y >= 16) yy -= 16;
		chunks[i]->tiles[xx][yy]->id = id;
	}
}


int getTileLight(int x, int y, int xc, int yc)
{
	int xx = x;
	int yy = y;
	int i = getChunkID(x, y, xc, yc);
	if (i != -1)
	{
		if (x < 0) xx += 16;
		if (x >= 16) xx -= 16;
		if (y < 0) yy += 16;
		if (y >= 16) yy -= 16;
		return chunks[i]->tiles[xx][yy]->light;
	}
	return -1;
}


void setTileLight(int x, int y, int xc, int yc, int light)
{
	int xx = x;
	int yy = y;
	int i = getChunkID(x, y, xc, yc);
	if (i != -1)
	{
		if (x < 0) xx += 16;
		if (x >= 16) xx -= 16;
		if (y < 0) yy += 16;
		if (y >= 16) yy -= 16;
		chunks[i]->tiles[xx][yy]->light = light;
	}
}


void lightDiamond(int x, int y, int xc, int yc, int light)
{
	if (light > 0)
	{
		if (getTileLight(x, y - 1, xc, yc) < light && getTileID(x, y, xc, yc) == 0)
		{
			setTileLight(x, y - 1, xc, yc, light);
			lightDiamond(x, y - 1, xc, yc, light - 1);
		}

		if (getTileLight(x + 1, y, xc, yc) < light && getTileID(x, y, xc, yc) == 0)
		{
			setTileLight(x + 1, y, xc, yc, light);
			lightDiamond(x + 1, y, xc, yc, light - 1);
		}

		if (getTileLight(x, y + 1, xc, yc) < light && getTileID(x, y, xc, yc) == 0)
		{
			setTileLight(x, y + 1, xc, yc, light);
			lightDiamond(x, y + 1, xc, yc, light - 1);
		}

		if (getTileLight(x - 1, y, xc, yc) < light && getTileID(x, y, xc, yc) == 0)
		{
			setTileLight(x - 1, y, xc, yc, light);
			lightDiamond(x - 1, y, xc, yc, light - 1);
		}
	}
}


void generate(int xc, int yc)
{
	double noiseX, noiseY, noiseLvl;
	Chunk* c = new Chunk(xc, yc);

	for (int x = 0; x < 16; x++)
		for (int y = 0; y < 16; y++)
		{
			noiseX = (xc * 16.0 + x) * 0.015625;
			noiseY = (yc * 16.0 + y) * 0.015625;
			noiseLvl = noise.unsignedFBM(noiseX, noiseY, 3, 2.5, 0.3) + 0.625;
			c->tiles[x][y]->id = int(noiseLvl);

			c->tilesf[x][y]->id = 1;
		}
	chunks.push_back(c);
}


void initGen()
{
	for (int x = p.xc - loaddist; x < p.xc + loaddist + 1; x++)
		for (int y = p.yc - loaddist; y < p.yc + loaddist + 1; y++)
		{
			int i = getChunkID(0, 0, -x, -y);
			if (i == -1)
				generate(-x, -y);
		}
	for (int x = -1; x < 2; x++)
		for (int y = -1; y < 2; y++)
			setTileID(p.x + x, p.y + y, -p.xc, -p.yc, 0);
}


void renderMenu()
{
	Element ele(0, 0, 0, 0, 0, '0', "", "");

	rect.setFillColor(sf::Color(0, 0, 0, 32));
	rect.setOutlineColor(sf::Color(0, 0, 0, 0));
	rect.setPosition(0, 0);
	rect.setSize(sf::Vector2f(width, height));
	window.draw(rect);

	for (int i = 0; i < menu[pagenum]->btn.size(); i++)
	{
		ele = *menu[pagenum]->btn[i];
		ele.y += std::sin(ticks / 10.0) * 10 - 5;

		if (mpos.x >= ele.x && mpos.x <= ele.x + ele.w && mpos.y >= ele.y && mpos.y <= ele.y + ele.h)
		{
			rect.setFillColor(sf::Color(255, 64, 64));
			rect.setOutlineColor(sf::Color(255, 64, 64));
			text.setFillColor(sf::Color(255, 64, 64));
			ele.x -= 5; ele.y -= 5;
			ele.w += 10; ele.h += 10;
			ele.fsize += 5;

			if (!left && leftL)
			{
				switch (ele.evt)
				{
				case '0':
					pagenum = 0;
					break;
				case '1':
					pagenum = 1;
					break;
				case '2':
					pagenum = 2;
					break;
				case 'x':
					window.close();
					break;
				case 'c':
					ingame = true;
					break;
				case 's':
					std::fstream setting("res/settings.txt");
					setting << menu[pagenum]->tgl[0]->evt;
					setting.close();
					tilesize = (menu[pagenum]->tgl[0]->evt == 'n'  ? 8 : 32);
					p.rad = tilesize * 3;
					viewdist = std::floor(width / 16 / tilesize);
					break;
				}
			}
		}
		else
		{
			rect.setFillColor(sf::Color(128, 128, 128));
			rect.setOutlineColor(sf::Color(128, 128, 128));
			text.setFillColor(sf::Color(128, 128, 128));
		}

		rect.setOutlineThickness(5);
		rect.setSize(sf::Vector2f(ele.w, ele.h));
		rect.setPosition(ele.x, ele.y);
		rect.setTexture(tex[0]);
		window.draw(rect);

		text.setCharacterSize(ele.fsize);
		text.setString(ele.str);
		text.setPosition(ele.x, ele.y);
		text.setPosition(rect.getGlobalBounds().left + rect.getGlobalBounds().width * 0.5 - text.getGlobalBounds().width * 0.5, rect.getGlobalBounds().top + rect.getGlobalBounds().height * 0.5 - text.getGlobalBounds().height * 0.5 - ele.fsize * 0.25);
		window.draw(text);
	}

	for (int i = 0; i < menu[pagenum]->lbl.size(); i++)
	{
		ele = *menu[pagenum]->lbl[i];
		ele.y += std::sin(ticks / 10.0) * 10 - 5;

		rect.setFillColor(sf::Color(128, 128, 128));
		rect.setOutlineColor(sf::Color(128, 128, 128));
		rect.setSize(sf::Vector2f(ele.w, ele.h));
		rect.setPosition(ele.x, ele.y);
		rect.setTexture(tex[0]);
		window.draw(rect);

		text.setFillColor(sf::Color(128, 128, 128));
		text.setCharacterSize(ele.fsize);
		text.setString(ele.str);
		text.setPosition(ele.x, ele.y);
		text.setPosition(rect.getGlobalBounds().left + rect.getGlobalBounds().width * 0.5 - text.getGlobalBounds().width * 0.5, rect.getGlobalBounds().top + rect.getGlobalBounds().height * 0.5 - text.getGlobalBounds().height * 0.5 - ele.fsize * 0.25);
		window.draw(text);
	}

	for (int i = 0; i < menu[pagenum]->ttl.size(); i++)
	{
		ele = *menu[pagenum]->ttl[i];
		ele.y += std::sin(ticks / 10.0) * 10 - 5;

		rect.setSize(sf::Vector2f(ele.w, ele.h));
		rect.setPosition(ele.x, ele.y);

		text.setFillColor(sf::Color(255, 64, 64));
		text.setCharacterSize(ele.fsize);
		text.setString(ele.str);
		text.setPosition(ele.x, ele.y);
		text.setPosition(rect.getGlobalBounds().left + rect.getGlobalBounds().width * 0.5 - text.getGlobalBounds().width * 0.5, rect.getGlobalBounds().top + rect.getGlobalBounds().height * 0.5 - text.getGlobalBounds().height * 0.5 - ele.fsize * 0.25);
		window.draw(text);
	}

	for (int i = 0; i < menu[pagenum]->tgl.size(); i++)
	{
		ele = *menu[pagenum]->tgl[i];
		ele.y += std::sin(ticks / 10.0) * 10 - 5;

		text.setCharacterSize(ele.fsize);

		if (ele.evt == 'n')
		{
			rect.setFillColor(sf::Color(128, 128, 128));
			rect.setOutlineColor(sf::Color(128, 128, 128));
			text.setFillColor(sf::Color(128, 128, 128));
			text.setString(ele.str);
		}
		else if (ele.evt == 'y')
		{
			rect.setFillColor(sf::Color(255, 64, 64));
			rect.setOutlineColor(sf::Color(255, 64, 64));
			text.setFillColor(sf::Color(255, 64, 64));
			text.setString(ele.src);
		}

		if (mpos.x >= ele.x && mpos.x <= ele.x + ele.w && mpos.y >= ele.y && mpos.y <= ele.y + ele.h)
		{
			ele.x -= 5; ele.y -= 5;
			ele.w += 10; ele.h += 10;
			ele.fsize += 5;
			if (!left && leftL)
			{
				if (ele.evt == 'y')
					menu[pagenum]->tgl[i]->evt = 'n';
				else menu[pagenum]->tgl[i]->evt = 'y';
			}
		}

		rect.setOutlineThickness(5);
		rect.setSize(sf::Vector2f(ele.w, ele.h));
		rect.setPosition(ele.x, ele.y);
		rect.setTexture(tex[0]);
		window.draw(rect);

		text.setPosition(ele.x, ele.y);
		text.setPosition(rect.getGlobalBounds().left + rect.getGlobalBounds().width * 0.5 - text.getGlobalBounds().width * 0.5, rect.getGlobalBounds().top + rect.getGlobalBounds().height * 0.5 - text.getGlobalBounds().height * 0.5 - ele.fsize * 0.25);
		window.draw(text);
	}

	window.display();
}


void render()
{
	int i, xpos, ypos, id, idf;
	double light;
	window.clear();

#pragma warning (disable:4244)
	rect.setSize(sf::Vector2f(tilesize, tilesize));
	rect.setOutlineThickness(0);

	// Get all chunks in view distance
	for (int cx = p.xc - viewdist; cx < p.xc + viewdist + 1; cx++)
		for (int cy = p.yc - viewdist; cy < p.yc + viewdist + 1; cy++)
		{
			// If chunk exists, draw it
			i = getChunkID(0, 0, -cx, -cy);
			if (i != -1)
			{
				// Draw all tiles in chunk
				for (int x = 0; x < 16; x++)
					for (int y = 0; y < 16; y++)
					{
						xpos = width / 2 + (chunks[i]->x * 16.0 + x + p.xc * 16.0 - p.x) * tilesize - tilesize / 2;
						ypos = height / 2 + (chunks[i]->y * 16.0 + y + p.yc * 16.0 - p.y) * tilesize - tilesize / 2;
						rect.setPosition(xpos, ypos);

						//light = (chunks[i]->tiles[x][y]->light + 1) / 16;
						light = (getTileLight(x, y, -cx, -cy) + 4.0) / 16.0;
						if (light < 0.25) light = 0.25;
						int r = std::hash<time_t>{}(x * 3.0 / y - cx * 16.0 + y * 5.0 - cy * 16.0 / x * cy) % 4;

						// Get id of tile, then set fill color
						rect.setFillColor(sf::Color(255 * light, 255 * light, 255 * light));
						id = chunks[i]->tiles[x][y]->id;
						switch (id)
						{
						case 0:
							idf = chunks[i]->tilesf[x][y]->id;
							rect.setFillColor(sf::Color(160 * light, 160 * light, 160 * light));
							rect.setTexture(tex[idf]);
							break;
						default:
							rect.setTexture(tex[id]);
						}
						window.draw(rect);
					}
			}
		}

	if (p.mineprog > 0)
	{
		int xpos = width / 2 - p.rad / 2 + tilesize;
		int ypos = height / 2 - p.rad / 2 + tilesize;
		rect.setTextureRect(sf::IntRect(9.5 * 32, 32 * 1.5, 1, 1));
		rect.setFillColor(sf::Color(255 * (p.mineprog * 0.066 + 0.33), 255 * (p.mineprog * 0.066 + 0.33), 255 * (p.mineprog * 0.066 + 0.33), 128));
		
		cnvx.setFillColor(sf::Color(255 * (p.mineprog * 0.066 + 0.33), 0, 0, 128));
		cnvx.setPointCount(3);
		cnvx.setPoint(0, sf::Vector2f(width / 2, height / 2));
		cnvx.setPoint(1, sf::Vector2f(width / 2, height / 2));
		cnvx.setPoint(2, sf::Vector2f(width / 2, height / 2));

		switch (p.rot)
		{
		case 0:
			rect.setPosition(xpos - tilesize, ypos - tilesize * (2 + p.minedistcur));
			rect.setSize(sf::Vector2f(p.rad, tilesize));
			window.draw(rect);

			cnvx.setPoint(1, sf::Vector2f(width / 2 - p.rad / 2, height / 2 - (p.rad / 2 + tilesize * p.minedistcur)));
			cnvx.setPoint(2, sf::Vector2f(width / 2 + p.rad / 2, height / 2 - (p.rad / 2 + tilesize * p.minedistcur)));
			break;
		case 90:
			rect.setPosition(xpos + tilesize * (2 + p.minedistcur), ypos - tilesize);
			rect.setSize(sf::Vector2f(tilesize, p.rad));
			window.draw(rect);

			cnvx.setPoint(1, sf::Vector2f(width / 2 + (p.rad / 2 + tilesize * p.minedistcur), height / 2 - p.rad / 2));
			cnvx.setPoint(2, sf::Vector2f(width / 2 + (p.rad / 2 + tilesize * p.minedistcur), height / 2 + p.rad / 2));
			break;
		case 180:
			rect.setPosition(xpos - tilesize, ypos + tilesize * (2 + p.minedistcur));
			rect.setSize(sf::Vector2f(p.rad, tilesize));
			window.draw(rect);

			cnvx.setPoint(1, sf::Vector2f(width / 2 - p.rad / 2, height / 2 + (p.rad / 2 + tilesize * p.minedistcur)));
			cnvx.setPoint(2, sf::Vector2f(width / 2 + p.rad / 2, height / 2 + (p.rad / 2 + tilesize * p.minedistcur)));
			break;
		case 270:
			rect.setPosition(xpos - tilesize * (2 + p.minedistcur), ypos - tilesize);
			rect.setSize(sf::Vector2f(tilesize, p.rad));
			window.draw(rect);

			cnvx.setPoint(1, sf::Vector2f(width / 2 - (p.rad / 2 + tilesize * p.minedistcur), height / 2 - p.rad / 2));
			cnvx.setPoint(2, sf::Vector2f(width / 2 - (p.rad / 2 + tilesize * p.minedistcur), height / 2 + p.rad / 2));
			break;
		}

		window.draw(cnvx);
	}

	rect.setFillColor(sf::Color(255, 255, 255));
	rect.setTextureRect(sf::IntRect(8 * 32, 0, 96, 96));
	rect.setPosition(width / 2 - p.rad / 2, height / 2 - p.rad / 2);
	rect.setSize(sf::Vector2f(p.rad, p.rad));
	window.draw(rect);

	if (ininv)
	{
		rect.setFillColor(sf::Color(0, 0, 0, 128));
		rect.setSize(sf::Vector2f(width, height));
		rect.setPosition(0, 0);
		rect.setTextureRect(sf::IntRect(9.5 * 32, 32 * 1.5, 1, 1));
		window.draw(rect);
	}

	window.display();
}


void update()
{
	if (!ininv)
	{
		for (int x = p.xc - loaddist; x < p.xc + loaddist + 1; x++)
			for (int y = p.yc - loaddist; y < p.yc + loaddist + 1; y++)
			{
				int i = getChunkID(0, 0, -x, -y);
				if (i == -1)
					generate(-x, -y);
			}

		int lastposx = p.x;
		int lastposy = p.y;

		int movey = -int(w) + int(s);
		int movex = -int(a) + int(d);

		double shiftm = p.speed;
		if (!shift)
		{
			shiftm = 1;
			p.minespeed = 1;
		}
		else
		{
			p.minespeed = 3;
		}

		// Move up
		if (movey < 0)
			for (int i = 0; i < shiftm * abs(movey); i++)
			{
				bool move = true;
				for (int x = -1; x < 2; x++)
					if (getTileID(p.x + x, p.y - 2, -p.xc, -p.yc) != 0)
						move = false;
				if (move) p.y--;
			}
		// Move down
		if (movey > 0)
			for (int i = 0; i < shiftm * abs(movey); i++)
			{
				bool move = true;
				for (int x = -1; x < 2; x++)
					if (getTileID(p.x + x, p.y + 2, -p.xc, -p.yc) != 0)
						move = false;
				if (move) p.y++;
			}
		// Move left
		if (movex < 0)
			for (int i = 0; i < shiftm * abs(movex); i++)
			{
				bool move = true;
				for (int y = -1; y < 2; y++)
					if (getTileID(p.x - 2, p.y + y, -p.xc, -p.yc) != 0)
						move = false;
				if (move) p.x--;
			}
		// Move right
		if (movex > 0)
			for (int i = 0; i < shiftm * abs(movex); i++)
			{
				bool move = true;
				for (int y = -1; y < 2; y++)
					if (getTileID(p.x + 2, p.y + y, -p.xc, -p.yc) != 0)
						move = false;
				if (move) p.x++;
			}

		// Correct movement between chunks
		if (p.y < 0) { p.y += 16; p.yc++; }
		if (p.y >= 16) { p.y -= 16; p.yc--; }
		if (p.x < 0) { p.x += 16; p.xc++; }
		if (p.x >= 16) { p.x -= 16; p.xc--; }

		if (p.x != lastposx || p.y != lastposy)
		{
			p.minedistcur = 0;
		}

		// Destroys tiles
		if (left)
		{
			for (int s = 0; s < p.minespeed; s++)
			{
				if (p.mineprog >= 10)
				{
					for (int i = -1; i < 2; i++)
					{
						switch (p.rot)
						{
						case 0:
							setTileID(p.x + i, p.y - (2 + p.minedistcur), -p.xc, -p.yc, 0);
							break;
						case 90:
							setTileID(p.x + (2 + p.minedistcur), p.y + i, -p.xc, -p.yc, 0);
							break;
						case 180:
							setTileID(p.x + i, p.y + (2 + p.minedistcur), -p.xc, -p.yc, 0);
							break;
						case 270:
							setTileID(p.x - (2 + p.minedistcur), p.y + i, -p.xc, -p.yc, 0);
						}
					}
					p.mineprog -= 10;
					p.minedistcur++;
					if (p.minedistcur >= p.minedist)
						p.minedistcur -= p.minedist;
				}
				p.mineprog++;
			}
		}
		else
		{
			p.mineprog = 0;
			p.minedistcur = 0;
		}

		// Sets rotation
		double deg = (std::atan2(width / 2 - mpos.x, height / 2 - mpos.y) * 180.0) / -3.1416;
		if (deg < 0) deg += 360;
		int lastrot = p.rot;

		if (deg >= 360 - 22.5 || deg < 22.5) p.rot = 0;
		if (deg >= 45 - 22.5 && deg < 45 + 22.5) p.rot = 45;
		if (deg >= 90 - 22.5 && deg < 90 + 22.5) p.rot = 90;
		if (deg >= 135 - 22.5 && deg < 135 + 22.5) p.rot = 135;
		if (deg >= 180 - 22.5 && deg < 180 + 22.5) p.rot = 180;
		if (deg >= 225 - 22.5 && deg < 225 + 22.5) p.rot = 225;
		if (deg >= 270 - 22.5 && deg < 270 + 22.5) p.rot = 270;
		if (deg >= 315 - 22.5 && deg < 315 + 22.5) p.rot = 315;

		if (p.rot != lastrot)
		{
			p.minedistcur = 0;
			p.mineprog = 0;
		}

		for (int x = -15; x < 16; x++)
			for (int y = -15; y < 16; y++)
				setTileLight(p.x + x, p.y + y, -p.xc, -p.yc, 0);
		lightDiamond(p.x, p.y, -p.xc, -p.yc, 12);
	}	
	else
	{
		p.minedistcur = 0;
		p.mineprog = 0;
	}
}


void updateKey()
{
	if (!e && eL)
	{
		ininv = !ininv;
	}
}


void getkey()
{
	w = GetKeyState(0x57) < 0;
	s = GetKeyState(0x53) < 0;
	a = GetKeyState(0x41) < 0;
	d = GetKeyState(0x44) < 0;

	eL = e;
	e = GetKeyState(0x45) < 0;

	shift = GetKeyState(0x10) < 0;

	leftL = left;
	left = GetKeyState(0x01) < 0;

	GetCursorPos(&mpos);
	ScreenToClient(window.getSystemHandle(), &mpos);
}


int main()
{
	window.setFramerateLimit(60);

	//texture.loadFromFile("res/blocks/textures.png");
	//rect.setTexture(&texture);
	tex[0]->loadFromFile("res/air.png");
	tex[1]->loadFromFile("res/stone.png");
	//tex[1]->loadFromFile("res/.png");

	font.loadFromFile("res/cas.ttf");
	text.setFont(font);

	std::string data;

	std::fstream setting("res/blocks/settings.txt");
	std::vector<char>settings;
	while (std::getline(setting, data))
		settings.push_back(data[0]);
	setting.close();
	int setreq = 0;

	std::fstream mfile("res/blocks/menu.txt", std::ios::in);
	int count = -1;
	bool quote = false;
	while (std::getline(mfile, data))
	{
		if (data == "new")
		{
			count++;
			menu.push_back(new Menu());
		}
		else
		{
			Element* e = new Element(
				stoi(std::string(1, data[4]) + std::string(1, data[5]) + std::string(1, data[6])),
				stoi(std::string(1, data[8]) + std::string(1, data[9]) + std::string(1, data[10])),
				stoi(std::string(1, data[12]) + std::string(1, data[13]) + std::string(1, data[14])),
				stoi(std::string(1, data[16]) + std::string(1, data[17]) + std::string(1, data[18])),
				stoi(std::string(1, data[20]) + std::string(1, data[21]) + std::string(1, data[22])),
				data[25],
				data.substr(29, data.find('\"', 29) - 29),
				data.substr(data.find('\"', 29) + 3, data.length() - 1 - (data.find('\"', 29) + 3))
			);
			if (e->evt == 'd')
			{
				e->evt = settings[setreq];
				tilesize = (settings[setreq] == 'n' ? 8 : 32);
				p.rad = tilesize * 3;
				viewdist = std::floor(width / 16 / tilesize);
				setreq++;
			}

			if (std::string(1, data[0]) + std::string(1, data[1]) + std::string(1, data[2]) == "btn")
				menu[count]->btn.push_back(e);
			if (std::string(1, data[0]) + std::string(1, data[1]) + std::string(1, data[2]) == "lbl")
				menu[count]->lbl.push_back(e);
			if (std::string(1, data[0]) + std::string(1, data[1]) + std::string(1, data[2]) == "ttl")
				menu[count]->ttl.push_back(e);
			if (std::string(1, data[0]) + std::string(1, data[1]) + std::string(1, data[2]) == "tgl")
				menu[count]->tgl.push_back(e);
		}
	}
	mfile.close();

	initGen();

	while (window.isOpen())
	{
		sf::Event event;
		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
				window.close();
			if (event.type == sf::Event::GainedFocus)
				focus = true;
			if (event.type == sf::Event::LostFocus)
				focus = false;
		}

#pragma warning(disable:4244)
		now = std::chrono::time_point_cast<std::chrono::milliseconds>(std::chrono::system_clock::now()).time_since_epoch().count();
		if (last == 0) 
			last = now;
		delta += now - last;
		last = now;

		while (delta >= tps)
		{
			delta -= tps;
			ticks++;
			update();
		}

		if (ingame)
			render();
		else
			renderMenu();

		if (focus)
		{
			getkey();
			updateKey();
		}
	}

	return 0;
}
