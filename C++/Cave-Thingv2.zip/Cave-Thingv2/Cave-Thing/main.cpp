/*
A shitty game that is sort of like Minecraft from a top down view, but I don't want to learn 3d maths.
If you are reading this, good luck. This code follows the rule of "if it works, it works".
- Ben Hamilton - Nov 6, 2022
*/

#include "SFML/Graphics.hpp"
#include <chrono>
#include <thread>
#include <windows.h>
#include <iostream>
#include <sstream>
#include "SimplexNoise.hpp"
#include <vector>
#include <functional>
#include <string>
#include <fstream>
#include <iomanip>
#include <direct.h>


SimplexNoise noise;


struct Item
{
	int
		id = 0,
		count = 0;
	Item(int idP, int countP)
	{
		id = idP;
		count = countP;
	}
};


struct Tile
{
	char
		id = 0,
		grow = 0,
		light = 0;
};


struct Element
{
	int
		x = 0, 
		y = 0, 
		w = 0, 
		h = 0, 
		fsize = 30;

	std::string
		str = "",
		src = "res/among.png";

	Element(int xP, int yP, int wP, int hP, int fsizeP, std::string strP, std::string srcP)
	{
		x = xP;
		y = yP;
		w = wP;
		h = hP;
		fsize = fsizeP;
		str = strP;
		src = srcP;
	}
};


struct Menu
{
	std::vector<Element*> img;
	std::vector<Element*> lbl;
	std::vector<Element*> ttl;
	std::vector<Element*> inp;
	std::vector<Element*> btn;
	int selID = -1;
};


int
	width = 960,
	height = 720,
	mwidth = 500,
	mheight = 500,

	tps = 1000 / 20,

	tilesize = 32,
	viewdist = 1,
	loaddist = 6,

	pagenum = 0;

long
	now = 0,
	last = 0,
	delta = 0,

	ticks = 0,
	ticksS = 0,

	seed;

bool
	w = false, wL = false,
	a = false, aL = false,
	s = false, sL = false,
	d = false, dL = false,
	q = false, qL = false,
	e = false, eL = false,
	r = false, rL = false,
	esc = false, escL = false,
	ctrl = false, ctrlL = false,
	shift = false, shiftL = false,
	enter = false, enterL = false,

	left = false, leftL = false,
	right = false, rightL = false,

	focus = true,
	ininv = false,
	ingame = false,
	pause = false;


struct Chunk
{
	int
		x = 0,
		y = 0;
	bool saved = false;
	Tile** tiles[16];
	Tile** tilesf[16];
	Chunk(int xP, int yP)
	{
		x = xP;
		y = yP;

		for (int x = 0; x < 16; x++)
		{
			tiles[x] = new Tile*[16];
			tilesf[x] = new Tile*[16];
			for (int y = 0; y < 16; y++)
			{
				tiles[x][y] = new Tile;
				tilesf[x][y] = new Tile;
			}
		}
	}
};
std::vector<Chunk*> chunks;


struct Player
{
	int
		x = 0,
		y = 0,
		xc = 0,
		yc = 0,
		rad = tilesize * 3,
		dir = 0,
		anprog = 0,
		invsel = 0,
		health = 50,
		damage = 10,
		speed = 2;
	bool
		light = true;
};
Player p;


sf::RenderWindow window(sf::VideoMode(width, height), "Cave", sf::Style::Titlebar | sf::Style::Close);
sf::RectangleShape rect;
sf::Texture texture;
sf::Font font;
sf::Text text;


void save()
{

}


void load()
{

}


int getChunkID(int x, int y, int xc, int yc)
{
	int xx = xc;
	int yy = yc;
	if (x < 0) xx--;
	if (x >= 16) xx++;
	if (y < 0) yy--;
	if (y >= 16) yy++;

	for (int i = 0; i < chunks.size(); i++)
		if (chunks[i]->x == xx && chunks[i]->y == yy)
			return i;
	return -1;
}


int getTileID(int x, int y, int xc, int yc)
{
	int xx = x;
	int yy = y;
	int i = getChunkID(x, y, xc, yc);
	if (i != -1)
	{
		if (x < 0) xx += 16;
		if (x >= 16) xx -= 16;
		if (y < 0) yy += 16;
		if (y >= 16) yy -= 16;
		return chunks[i]->tiles[xx][yy]->id;
	}
	return -1;
}


void setTileID(int x, int y, int xc, int yc, int id)
{
	int xx = x;
	int yy = y;
	int i = getChunkID(x, y, xc, yc);
	if (i != -1)
	{
		if (x < 0) xx += 16;
		if (x >= 16) xx -= 16;
		if (y < 0) yy += 16;
		if (y >= 16) yy -= 16;
		chunks[i]->tiles[xx][yy]->id = id;
	}
}


void generate(int xc, int yc)
{
	double noiseX, noiseY, noiseLvl;
	Chunk* c = new Chunk(xc, yc);

	for (int x = 0; x < 16; x++)
		for (int y = 0; y < 16; y++)
		{
			noiseX = (xc * 16.0 + x) * 0.0078125;
			noiseY = (yc * 16.0 + y) * 0.0078125;
			noiseLvl = noise.unsignedFBM(noiseX, noiseY, 3, 2.5, 0.3) + 0.625;
			c->tiles[x][y]->id = int(noiseLvl);

			c->tilesf[x][y]->id = 1;
		}
	chunks.push_back(c);
}


void initGen()
{
	for (int x = p.xc - loaddist; x < p.xc + loaddist + 1; x++)
		for (int y = p.yc - loaddist; y < p.yc + loaddist + 1; y++)
		{
			int i = getChunkID(0, 0, -x, -y);
			if (i == -1)
				generate(-x, -y);
		}
	for (int x = -1; x < 2; x++)
		for (int y = -1; y < 2; y++)
			setTileID(p.x, p.y, -p.xc, -p.yc, 0);
	p.x -= 5;
}


void renderMenu()
{

}


void render()
{
	int i, xpos, ypos, id, idf;
	double light;
	window.clear();

#pragma warning (disable:4244)
	rect.setSize(sf::Vector2f(tilesize, tilesize));

	// Get all chunks in view distance
	for (int cx = p.xc - viewdist; cx < p.xc + viewdist + 1; cx++)
		for (int cy = p.yc - viewdist; cy < p.yc + viewdist + 1; cy++)
		{
			// If chunk exists, draw it
			i = getChunkID(0, 0, -cx, -cy);
			if (i != -1)
			{
				// Draw all tiles in chunk
				for (int x = 0; x < 16; x++)
					for (int y = 0; y < 16; y++)
					{
						xpos = width / 2 + (chunks[i]->x * 16.0 + x + p.xc * 16.0 - p.x) * tilesize - tilesize / 2;
						ypos = height / 2 + (chunks[i]->y * 16.0 + y + p.yc * 16.0 - p.y) * tilesize - tilesize / 2;
						rect.setPosition(xpos, ypos);

						light = (chunks[i]->tiles[x][y]->light + 1) / 16;
						if (light < 0.25) light = 0.25;
						int r = std::hash<time_t>{}(x * 3.0 - cx * 16.0 + y * 2.0 - cy * 16.0) % 3;

						// Get id of tile, then set fill color
						rect.setFillColor(sf::Color(255 * light, 255 * light, 255 * light));
						id = chunks[i]->tiles[x][y]->id;
						switch (id)
						{
						case 0:
							idf = chunks[i]->tilesf[x][y]->id;
							rect.setFillColor(sf::Color(192 * light, 192 * light, 192 * light));
							switch (idf)
							{
							case 0:
								rect.setTextureRect(sf::IntRect(0, 0, 32, 32));
								break;
							case 1:
								rect.setTextureRect(sf::IntRect(32 + r * 32, 0, 32, 32));
								break;
							}
							break;
						case 1:
							rect.setTextureRect(sf::IntRect(32 + r * 32, 0, 32, 32));
							break;
						}

						// Draw chunk borders
						/*if (x == 0 || y == 0)
							if ((cx % 2 + cy % 2) % 2) rect.setFillColor(sf::Color(128, 128, 128));
							else rect.setFillColor(sf::Color(160, 160, 160));*/

						window.draw(rect);
					}
			}
		}

	// Draw player
	rect.setFillColor(sf::Color(255, 255, 255));
	rect.setTextureRect(sf::IntRect(8 * 32, 0, 96, 96));
	rect.setPosition(width / 2 - p.rad / 2, height / 2 - p.rad / 2);
	rect.setSize(sf::Vector2f(p.rad, p.rad));
	window.draw(rect);

	window.display();
}


void update()
{
	for (int x = p.xc - loaddist; x < p.xc + loaddist + 1; x++)
		for (int y = p.yc - loaddist; y < p.yc + loaddist + 1; y++)
		{
			int i = getChunkID(0, 0, -x, -y);
			if (i == -1)
				generate(-x, -y);
		}

	int movey = -int(w) + int(s);
	int movex = -int(a) + int(d);
	double shiftm = p.speed;
	if (shift) shiftm = 1;

	// Move up
	if (movey < 0)
		for (int i = 0; i < shiftm * abs(movey); i++)
		{
			bool move = true;
			for (int x = -1; x < 2; x++)
				if (getTileID(p.x + x, p.y - 2, -p.xc, -p.yc) != 0)
					move = false;
			if (move) p.y--;
		}
	// Move down
	if (movey > 0)
		for (int i = 0; i < shiftm * abs(movey); i++)
		{
			bool move = true;
			for (int x = -1; x < 2; x++)
				if (getTileID(p.x + x, p.y + 2, -p.xc, -p.yc) != 0)
					move = false;
			if (move) p.y++;
		}
	// Move left
	if (movex < 0)
		for (int i = 0; i < shiftm * abs(movex); i++)
		{
			bool move = true;
			for (int y = -1; y < 2; y++)
				if (getTileID(p.x - 2, p.y + y, -p.xc, -p.yc) != 0)
					move = false;
			if (move) p.x--;
		}
	// Move right
	if (movex > 0)
		for (int i = 0; i < shiftm * abs(movex); i++)
		{
			bool move = true;
			for (int y = -1; y < 2; y++)
				if (getTileID(p.x + 2, p.y + y, -p.xc, -p.yc) != 0)
					move = false;
			if (move) p.x++;
		}

	// Correct movement between chunks
	if (p.y < 0) {p.y += 16; p.yc++;}
	if (p.y >= 16) {p.y -= 16; p.yc--;}
	if (p.x < 0) {p.x += 16; p.xc++;}
	if (p.x >= 16) {p.x -= 16; p.xc--;}
}


void getkey()
{
	w = GetKeyState(0x57) < 0;
	s = GetKeyState(0x53) < 0;
	a = GetKeyState(0x41) < 0;
	d = GetKeyState(0x44) < 0;
	shift = GetKeyState(0x10) < 0;
}


int main()
{
	window.setFramerateLimit(60);

	ingame = true;

	texture.loadFromFile("res/blocks/textures.png");
	rect.setTexture(&texture);

	font.loadFromFile("res/cas.ttf");
	text.setFont(font);

	initGen();

	while (window.isOpen())
	{
		sf::Event event;
		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
				window.close();
			if (event.type == sf::Event::GainedFocus)
				focus = true;
			if (event.type == sf::Event::LostFocus)
				focus = false;
		}

#pragma warning(disable:4244)
		now = std::chrono::time_point_cast<std::chrono::milliseconds>(std::chrono::system_clock::now()).time_since_epoch().count();
		if (last == 0) 
			last = now;
		delta += now - last;
		last = now;

		while (delta >= tps)
		{
			delta -= tps;
			ticks++;
			update();
		}

		if (ingame)
			render();
		else
			renderMenu();

		if (focus)
			getkey();
	}

	return 0;
}
